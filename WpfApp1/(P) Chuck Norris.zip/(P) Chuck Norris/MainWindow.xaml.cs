﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Newtonsoft.Json;

namespace _P__Chuck_Norris
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            using (var client = new HttpClient())
            {

                string jsonData = client.GetStringAsync("https://api.chucknorris.io/jokes/categories").Result;
                var results = JsonConvert.DeserializeObject<List<string>>(jsonData);
                //RickAndMortyAPI api = JsonConvert.DeserializeObject<RickAndMortyAPI>(jsonData);
                foreach (var category in results)
                {
                    cboCategory.Items.Add(category);
                }





            }
        }

        private void btnCategory_Click(object sender, RoutedEventArgs e)
        {
            var selecteditem = cboCategory.SelectedItem;
            //List<string> SpecificCategoryJoke = new List<string>();

            using (var client = new HttpClient())
            {
                string json = client.GetStringAsync($"https://api.chucknorris.io/jokes/random?category={selecteditem}").Result;
                string results = JsonConvert.DeserializeObject(json).ToString();
                //         0                1                       2                                       3                                                                       4                               5                               7                                                                                         8                             
                // "categories":["animal"],"created_at":"2020-01-05 13:42:19.104863","icon_url":"https://assets.chucknorris.host/img/avatar/chuck-norris.png","id":"zjuwql5ns-mklqumqezlhg","updated_at":"2020-01-05 13:42:19.104863","url":"https://api.chucknorris.io/jokes/zjuwql5ns-mklqumqezlhg","value":"Chuck Norris can skeletize a cow in two minutes."

                
                for (int i = 0; i < results.Length; i++)
                {
                    string[] pieces = results.Split(":");

                    txtFunnyJoke.Text = results[8].ToString();

                }



            }
        }
    }
}
